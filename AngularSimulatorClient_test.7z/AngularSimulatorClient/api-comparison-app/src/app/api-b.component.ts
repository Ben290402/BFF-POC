import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-api-b',
  template: `
    <button (click)="callApiB()">Call API B</button>
    <p *ngIf="message">{{ message }}</p>
  `,
  styles: []
})
export class ApiBComponent {
  message: string = '';

  constructor(private http: HttpClient) {}

  callApiB() {
    const totalRequests = 10;
    let completedRequests = 0;

    this.message = 'Calling API B 10 times...';

    for (let i = 0; i < totalRequests; i++) {
      this.http.get<any>('http://localhost:3002/api/aggregate').subscribe({
        next: (response) => {
          console.log(`API B Response ${i + 1}:`, response);
          completedRequests++;
          if (completedRequests === totalRequests) {
            this.message = `Called API B ${totalRequests} times`;
          }
        },
        error: (error) => {
          console.error(`Error in API B request ${i + 1}:`, error);
        }
      });
    }
  }
}
