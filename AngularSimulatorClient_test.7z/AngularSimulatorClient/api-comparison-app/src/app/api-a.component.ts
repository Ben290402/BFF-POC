import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-api-a',
  template: `
    <button (click)="callApiA()">Call API A</button>
    <p *ngIf="message">{{ message }}</p>
  `,
  styles: []
})
export class ApiAComponent {
  message: string = '';

  constructor(private http: HttpClient) {}

  callApiA() {
    const totalRequests = 50;
    let completedRequests = 0;

    this.message = 'Calling API A 50 times...';

    for (let i = 0; i < totalRequests; i++) {
      this.http.get<any>('http://localhost:3001/api/object').subscribe({
        next: (response) => {
          console.log(`Response ${i + 1}:`, response);
          completedRequests++;
          if (completedRequests === totalRequests) {
            this.message = `Called API A ${totalRequests} times`;
          }
        },
        error: (error) => {
          console.error(`Error in request ${i + 1}:`, error);
        }
      });
    }
  }
}
