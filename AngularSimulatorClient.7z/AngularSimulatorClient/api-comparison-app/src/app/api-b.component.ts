import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-api-b',
  template: `
    <button (click)="callApiB()">Call API B</button>
    <p *ngIf="message">{{ message }}</p>
  `,
  styles: []
})
export class ApiBComponent {
  message: string = '';

  constructor(private http: HttpClient) {}

  callApiB() {
    const L = 1000;
    this.message = 'Calling API B...';
    for (let i = 0; i < L; i++) {
      this.http.get('http://localhost:3002/api/aggregate').subscribe();
    }
    this.message = `Called API B ${L} times`;
  }
}
