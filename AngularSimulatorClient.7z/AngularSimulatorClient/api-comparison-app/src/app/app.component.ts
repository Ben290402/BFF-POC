// src/app/app.component.ts

import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button (click)="callApiA()">Call API A</button>
    <button (click)="callApiB()">Call API B</button>

    <p *ngIf="message">{{ message }}</p>
  `,
  styles: []
})
export class AppComponent {
  message: string = '';

  constructor(private http: HttpClient) {}

  callApiA() {
    const totalRequests = 50; // Nombre total de requêtes à envoyer
    let completedRequests = 0; // Compteur de requêtes terminées

    this.message = 'Calling API A 50 times...';

    for (let i = 0; i < totalRequests; i++) {
      this.http.get<any>('http://localhost:3001/api/object').subscribe({
        next: (response) => {
          console.log(`Response ${i + 1}:`, response);
          completedRequests++;

          // Vérifier si toutes les requêtes sont terminées
          if (completedRequests === totalRequests) {
            this.message = `Called API A ${totalRequests} times`;
          }
        },
        error: (error) => {
          console.error(`Error in request ${i + 1}:`, error);
        }
      });
    }
  }

 callApiB() {
    const totalRequests = 10; // Nombre total de requêtes pour API B
    let completedRequests = 0;

    this.message = 'Calling API B 10 times...';

    for (let i = 0; i < totalRequests; i++) {
      this.http.get<any>('http://localhost:3002/api/aggregate').subscribe({
        next: (response) => {
          console.log(`API B Response ${i + 1}:`, response);
          completedRequests++;
          if (completedRequests === totalRequests) {
            this.message = `Called API B ${totalRequests} times`;
          }
        },
        error: (error) => {
          console.error(`Error in API B request ${i + 1}:`, error);
        }
      });
    }
  }
}