import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { ApiAComponent } from './api-a.component';
import { ApiBComponent } from './api-b.component';

const routes: Routes = [
  { path: 'api-a', component: ApiAComponent },
  { path: 'api-b', component: ApiBComponent },
  { path: '', redirectTo: '/api-a', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    ApiAComponent,
    ApiBComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
