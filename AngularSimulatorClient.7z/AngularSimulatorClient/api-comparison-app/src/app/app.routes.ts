import { Routes } from '@angular/router';
import { ApiAComponent } from './api-a.component';
import { ApiBComponent } from './api-b.component';

export const routes: Routes = [
  { path: 'api-a', component: ApiAComponent },
  { path: 'api-b', component: ApiBComponent },
  { path: '', redirectTo: '/api-a', pathMatch: 'full' }
];
