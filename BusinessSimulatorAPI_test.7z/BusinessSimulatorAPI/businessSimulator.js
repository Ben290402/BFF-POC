// businessSimulator.js

const express = require('express');
const cors = require('cors'); // Import the cors package
const app = express();
const PORT = 3001;

app.use(cors()); // Enable CORS for all routes

app.get('/api/object', (req, res) => {
  const fields = parseInt(req.query.fields) || 20;
  const length = parseInt(req.query.length) || 100;
  const obj = {};

  for (let i = 0; i < fields; i++) {
    obj[`field${i}`] = 'x'.repeat(length);
  }

  //Wait for 100 ms
    setTimeout(() => {
        res.json(obj);
    }, 100);
});

app.listen(PORT, () => {
  console.log(`API A is running on port ${PORT}`);
});