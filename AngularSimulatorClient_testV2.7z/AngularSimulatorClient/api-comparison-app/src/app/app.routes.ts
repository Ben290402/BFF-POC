import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApiAComponent } from './api-a.component';
import { ApiBComponent } from './api-b.component';

export const routes: Routes = [
  { path: 'api-a', component: ApiAComponent },
  { path: 'api-b', component: ApiBComponent },
  { path: '', redirectTo: 'api-a', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}