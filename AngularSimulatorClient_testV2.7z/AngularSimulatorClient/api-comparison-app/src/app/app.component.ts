import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <nav>
      <a routerLink="/api-a" routerLinkActive="active">API A</a>
      <a routerLink="/api-b" routerLinkActive="active">API B</a>
    </nav>
    <router-outlet></router-outlet>
  `,
  styles: [`
    nav {
      background-color: #f8f9fa;
      padding: 1em;
    }
    nav a {
      margin-right: 1em;
      text-decoration: none;
      color: #007bff;
    }
    nav a.active {
      font-weight: bold;
      text-decoration: underline;
    }
  `]
})
export class AppComponent {}
