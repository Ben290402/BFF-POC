import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-api-a',
  template: `
    <button (click)="callApiA()">Call API A</button>
    <p *ngIf="message">{{ message }}</p>
  `,
  styles: []
})
export class ApiAComponent {
  message: string = '';

  constructor(private http: HttpClient) {}

  callApiA() {
    const M = 1000;
    this.message = 'Calling API A...';
    for (let i = 0; i < M; i++) {
      this.http.get('http://localhost:3001/api/object').subscribe(c => {
        const values = Object.values(c);
        const half = values.filter((_, index) => index % 2 === 0);
        console.log(half);
      });
    }
    this.message = `Called API A ${M} times`;
  }
}
