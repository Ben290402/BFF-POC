// backForFrontSimulator.js

const express = require('express');
const axios = require('axios');
const cors = require('cors'); // Import the cors package
const app = express();
const PORT = 3002;

app.use(cors()); // Enable CORS for all routes

app.get('/api/aggregate', async (req, res) => {
  const calls = parseInt(req.query.calls) || 5;
  const fields = parseInt(req.query.fields) || 20;
  const length = parseInt(req.query.length) || 100;
  const resultFields = parseInt(req.query.resultFields) || 5;
  let aggregatedData = {};

  // Perform N calls to API A
  for (let i = 0; i < calls; i++) {
    await axios.get(`http://localhost:3001/api/object?fields=${fields}&length=${length}`);
    // Optionally process the response here
  }

  // Create an object with Z fields of Y characters
  for (let i = 0; i < resultFields; i++) {
    aggregatedData[`aggField${i}`] = 'x'.repeat(length);
  }

  res.json(aggregatedData);
});

app.listen(PORT, () => {
  console.log(`Back-for-front B is running on port ${PORT}`);
});